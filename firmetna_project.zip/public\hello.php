<?php
echo "<h1>🚀 Apache et PHP fonctionnent !</h1>";
echo "<p>L'heure du serveur : " . date('H:i:s') . "</p>";
phpinfo();
?>
