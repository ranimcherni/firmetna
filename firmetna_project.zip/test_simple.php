<?php
// test_simple.php - Test DIRECT sans autoload
echo '=== TEST SANS AUTOLOAD ===' . PHP_EOL;

// 1. Testez User Entity
require_once __DIR__ . '/src/Entity/User.php';
echo '? User.php charg?' . PHP_EOL;

$user = new App\Entity\User();
$user->setEmail('test@test.com');
echo '? Objet User cr??: ' . $user->getEmail() . PHP_EOL;

// 2. Testez UserController
require_once __DIR__ . '/src/Controller/UserController.php';
echo '? UserController charg?' . PHP_EOL;

// 3. Testez SecurityController  
require_once __DIR__ . '/src/Controller/SecurityController.php';
echo '? SecurityController charg?' . PHP_EOL;

echo '=== TOUT FONCTIONNE SANS AUTOLOAD ===' . PHP_EOL;

